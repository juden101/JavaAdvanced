package softUniParking;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        //Initialize the Parking
        Parking parking = new Parking(2);

        //Initialize Car
        Car car = new Car("Skoda", "Fabia", 65, "CC1856BG");

        //Initialize second Car object
        Car car2 = new Car("Audi", "A3", 110, "EB8787MN");

        System.out.println(car.toString());
        System.out.println(parking.addCar(car));
        System.out.println(parking.addCar(car2));

        System.out.println(parking.getCar("EB8787MN").toString());
        List<String> regNums = new ArrayList<>();

        //add two registrationNumbers
        regNums.add("EB8787MN");
        regNums.add("invalid");

        // call method removeSetOfRegistrationNumber with our list
        parking.removeSetOfRegistrationNumber(regNums);

        System.out.println(parking.getCount()); //1
    }
}