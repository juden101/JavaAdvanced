package CarDemo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int carCount = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < carCount; i++) {
            String[] carParts = scanner.nextLine().split("\\s+");
            Car current = new Car();
            current.setMake(carParts[0]);
            current.setModel(carParts[1]);
            current.setHorsePower(Integer.parseInt(carParts[2]));
            System.out.print(current.carInfo());
        }


    }
}
